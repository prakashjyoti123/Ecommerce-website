import Cart from "../model/cartSchema.js";

export const addItemInCart = (request, response) => {
  return response.json("Hello");
};
